package com.starhub.catalog2.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.neo4j.support.Neo4jTemplate;
import org.springframework.data.neo4j.support.node.Neo4jHelper;
import org.springframework.data.neo4j.template.Neo4jOperations;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.BeforeTransaction;
import org.springframework.transaction.annotation.Transactional;

import com.starhub.catalog2.exception.ApplicationException;
import com.starhub.catalog2.model.Attribute;
import com.starhub.catalog2.model.Group;
import com.starhub.catalog2.model.Product;
import com.starhub.catalog2.model.Product.Type;
import com.starhub.catalog2.service.CatalogService;

@ContextConfiguration(locations = "classpath:/spring/context.xml")
@RunWith(SpringJUnit4ClassRunner.class)
@Transactional
public class AppTest
{
	@Autowired CatalogService catalogService;
	@Autowired Neo4jOperations operations;
	@Autowired Neo4jTemplate template;
	
	@Rollback(false)
	@BeforeTransaction
	public void cleanup()
	{
		Neo4jHelper.cleanDb(template);
	}
	
	public void test1()
	{
		try
		{
			Group discounts = this.catalogService.createGroup("group-name", Product.Type.DISCOUNT, -1L, new Product[]
			{
				this.catalogService.createProduct("MOBL-90001", "discount-a", Product.Type.DISCOUNT),
				this.catalogService.createProduct("MOBL-90001", "discount-a", Product.Type.DISCOUNT)
			});
			
			Product promotion = this.catalogService.createProduct("BNDL-10001", "promotion-a", Product.Type.PROMOTION);
			promotion.getCanHaves().add(discounts);
			
			promotion.getOffers().add(
				this.catalogService.createOffer(
					this.catalogService.createProduct("MOBL-10353", "SmartSurf Lite", Product.Type.PLAN, new Attribute[]
					{
						this.catalogService.createAttribute("Mode of Service", Attribute.Type.LOV, null, new String[] 
						{
							Attribute.Mobile.ModeOfService._4G
						}),
						this.catalogService.createAttribute("Type of Plan", Attribute.Type.LOV, null, new String[]
						{
							Attribute.Mobile.TypeOfPlan.STANDALONE,
							Attribute.Mobile.TypeOfPlan.FAMILY_SHARE_PARENT,
							Attribute.Mobile.TypeOfPlan.FAMILY_SHARE_CHILD
						})
					}),
					this.catalogService.createProduct("NNI-MOBL-10001", "iPhone 5", Product.Type.DEVICE), 
					this.catalogService.createProduct("MOBL-40001", "ETC $700", Product.Type.COMMITMENT),
					99L
				)
			);
			
			promotion.getOffers().add(
					this.catalogService.createOffer(
						this.catalogService.createProduct("MOBL-10354", "SmartSurf Premium", Product.Type.PLAN, new Attribute[]
						{
							this.catalogService.createAttribute("Mode of Service", Attribute.Type.LOV, null, new String[] 
							{
								"2G",
								"3G",
								"4G"
							}),
							this.catalogService.createAttribute("Type of Plan", Attribute.Type.LOV, null, new String[]
							{
								"Standalone",
								"Family Share Parent",
								"Family Share Child"
							})
						}),
						this.catalogService.findProductByCode("NNI-MOBL-10001"), 
						this.catalogService.findProductByCode("MOBL-40001"),
						199L
					)
				);
			
			this.catalogService.saveAll();
			
			System.out.println(this.operations.findOne(promotion.getId(), Product.class).getOffers().size());
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
		}
	}
	
	@Test
	public void test2()
	{
		try
		{
			Product one = this.catalogService.createProduct("MOBL-10001", "Mobile", Type.ROOT);
			Product two = this.catalogService.createProduct("MOBL-10002", "Mobile", Type.ROOT);
			
			System.out.println(one.equals(two));
		}
		catch (ApplicationException applicationException)
		{
			applicationException.printStackTrace();
		}
	}
}
