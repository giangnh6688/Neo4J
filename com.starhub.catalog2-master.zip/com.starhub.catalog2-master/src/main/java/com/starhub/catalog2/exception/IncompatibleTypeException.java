package com.starhub.catalog2.exception;

public class IncompatibleTypeException extends Exception
{
	private static final long serialVersionUID = -4486151107210115052L;
	
	public IncompatibleTypeException()
	{
	}
	
	public IncompatibleTypeException(String message)
	{
		super(message);
	}
	
	public IncompatibleTypeException(String message, Throwable throwable)
	{
		super(message, throwable);
	}
}
