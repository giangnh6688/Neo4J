package com.starhub.catalog2.model;

import org.springframework.data.neo4j.annotation.GraphId;
import org.springframework.data.neo4j.annotation.NodeEntity;

@NodeEntity
public class Offer
{
	@GraphId
	protected Long id;

	protected Product plan;
	protected Product device;
	protected Product commitment;
	protected Long price;

	public Long getId()
	{
		return id;
	}

	public void setId(Long id)
	{
		this.id = id;
	}

	public Product getPlan()
	{
		return plan;
	}

	public void setPlan(Product plan)
	{
		this.plan = plan;
	}

	public Product getDevice()
	{
		return device;
	}

	public void setDevice(Product device)
	{
		this.device = device;
	}

	public Product getCommitment()
	{
		return commitment;
	}

	public void setCommitment(Product commitment)
	{
		this.commitment = commitment;
	}

	public Long getPrice()
	{
		return price;
	}

	public void setPrice(Long price)
	{
		this.price = price;
	}
	
	@Override
	public int hashCode()
	{
		return (id == null) ? 0 : id.hashCode();
	}
	
	@Override
	public boolean equals(Object obj)
	{
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		
		Offer other = (Offer) obj;
		if (id == null) return other.id == null;
		return id.equals(other.id);
	}
	
	@Override
	public String toString()
	{
		return String.format("Offer{id=%03d}", id);
	}
}
