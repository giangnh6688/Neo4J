package com.starhub.catalog2.model;

import org.springframework.data.neo4j.annotation.GraphId;
import org.springframework.data.neo4j.annotation.NodeEntity;

@NodeEntity
public class Attribute
{
	public interface Mobile
	{
		public interface ModeOfService
		{
			public static final String _2G = "2G";
			public static final String _3G = "3G";
			public static final String _4G = "4G";
		}
		
		public interface TypeOfPlan
		{
			public static final String STANDALONE = "Standalone";
			public static final String FAMILY_SHARE_PARENT = "FamilyShare Parent";
			public static final String FAMILY_SHARE_CHILD = "FamilyShare Child";
		}
	}
	
	public enum Type
	{
		STRING	("STRING"),
		NUMERIC	("NUMERIC"), 
		DATE	("DATE"), 
		BOOLEAN	("BOOLEAN"), 
		LOV		("LOV");

		private String name;

		private Type(String name)
		{
			this.name = name;
		}

		public String getName()
		{
			return this.name;
		}
	}

	@GraphId
	protected Long id;

	protected String name;
	protected Type type;
	protected String pattern;
	protected String[] lov;

	public Long getId()
	{
		return id;
	}

	public void setId(Long id)
	{
		this.id = id;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public Type getType()
	{
		return type;
	}

	public void setType(Type type)
	{
		this.type = type;
	}

	public String getPattern()
	{
		return pattern;
	}

	public void setPattern(String pattern)
	{
		this.pattern = pattern;
	}

	public String[] getLov()
	{
		return lov;
	}

	public void setLov(String[] lov)
	{
		this.lov = lov;
	}
	
	@Override
	public int hashCode()
	{
		return (id == null) ? 0 : id.hashCode();
	}
	
	@Override
	public boolean equals(Object obj)
	{
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		
		Attribute other = (Attribute) obj;
		if (id == null) return other.id == null;
		return id.equals(other.id);
	}

	@Override
	public String toString()
	{
		return String.format("Attribute{id=%03d, type=%s, name=%s}", id, type, name);
	}
}
