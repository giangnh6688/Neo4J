package com.starhub.catalog2.model;

import java.util.HashSet;
import java.util.Set;

import org.neo4j.graphdb.Direction;
import org.springframework.data.neo4j.annotation.GraphId;
import org.springframework.data.neo4j.annotation.Indexed;
import org.springframework.data.neo4j.annotation.NodeEntity;
import org.springframework.data.neo4j.annotation.RelatedTo;
import org.springframework.data.neo4j.support.index.IndexType;

@NodeEntity
public class Product
{
	public enum Type
	{
		COMMITMENT	("COMMITMENT"),
		DEVICE		("DEVICE"),
		DISCOUNT	("DISCOUNT"),
		GROUP		("GROUP"),
		HANDSET		("HANDSET"),
		OFFER		("OFFER"),
		PLAN		("PLAN"),
		PREMIUM		("PREMIUM"),
		PROMOTION	("PROMOTION"),
		ROOT		("ROOT");
		
		private String name;
		
		private Type(String name)
		{
			this.name = name;
		}
		
		public String getName()
		{
			return this.name;
		}
	}
	
	@GraphId
	protected Long id;
	
	@Indexed(indexName = "product-code-index", indexType = IndexType.UNIQUE, unique = true)
	protected String code;
	
	@Indexed(indexName = "product-name-index")
	protected String name;
	
	@Indexed(indexName = "product-type-index")
	protected Type type;
	
	@RelatedTo(type = Relationship.CAN_HAVE, direction = Direction.OUTGOING)
	protected Set<Group> canHaves = new HashSet<Group>();
	
	@RelatedTo(type = Relationship.MUST_HAVE, direction = Direction.OUTGOING)
	protected Set<Group> mustHaves = new HashSet<Group>();
	
	@RelatedTo(type = Relationship.OFFERS, direction = Direction.OUTGOING)
	protected Set<Offer> offers = new HashSet<Offer>();
	
	@RelatedTo(type = Relationship.HAS, direction = Direction.OUTGOING)
	protected Set<Attribute> attributes = new HashSet<Attribute>();
	
	public Long getId()
	{
		return id;
	}

	public void setId(Long id)
	{
		this.id = id;
	}

	public String getCode()
	{
		return code;
	}

	public void setCode(String code)
	{
		this.code = code;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public Type getType()
	{
		return type;
	}

	public void setType(Type type)
	{
		this.type = type;
	}

	public Set<Group> getCanHaves()
	{
		return canHaves;
	}

	public void setCanHaves(Set<Group> canHaves)
	{
		this.canHaves = canHaves;
	}

	public Set<Group> getMustHaves()
	{
		return mustHaves;
	}

	public void setMustHaves(Set<Group> mustHaves)
	{
		this.mustHaves = mustHaves;
	}

	public Set<Offer> getOffers()
	{
		return offers;
	}

	public void setOffers(Set<Offer> offers)
	{
		this.offers = offers;
	}

	public Set<Attribute> getAttributes()
	{
		return attributes;
	}

	public void setAttributes(Set<Attribute> attributes)
	{
		this.attributes = attributes;
	}

	@Override
	public int hashCode()
	{
		return (id == null) ? 0 : id.hashCode();
	}
	
	@Override
	public boolean equals(Object obj)
	{
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		
		Product other = (Product) obj;
		if (id == null) return other.id == null;
		return id.equals(other.id);
	}

	@Override
	public String toString()
	{
		return String.format("Product{id=%03d, type=%s, code=%s, name=%s}", id, type, code, name);
	}
}
