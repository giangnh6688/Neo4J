package com.starhub.catalog2.repo;

import org.springframework.data.neo4j.repository.GraphRepository;

import com.starhub.catalog2.model.Product;

public interface ProductRepository extends GraphRepository<Product>
{

}
