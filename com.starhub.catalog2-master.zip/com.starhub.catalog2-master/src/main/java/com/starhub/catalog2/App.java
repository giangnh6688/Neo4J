package com.starhub.catalog2;

public class App
{
	public static void main(String[] args)
	{
		System.out.println("hello world!");
	}
}
