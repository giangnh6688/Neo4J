package com.starhub.catalog2.service;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.starhub.catalog2.exception.ApplicationException;
import com.starhub.catalog2.exception.IncompatibleTypeException;
import com.starhub.catalog2.model.Attribute;
import com.starhub.catalog2.model.Group;
import com.starhub.catalog2.model.Offer;
import com.starhub.catalog2.model.Product;
import com.starhub.catalog2.repo.AttributeRepository;
import com.starhub.catalog2.repo.GroupRepository;
import com.starhub.catalog2.repo.OfferRepository;
import com.starhub.catalog2.repo.ProductRepository;

@Service
public class CatalogService
{
	@Autowired private AttributeRepository attributeRepository;
	@Autowired private GroupRepository groupRepository;
	@Autowired private OfferRepository offerRepository;
	@Autowired private ProductRepository productRepository;

//	@Autowired private Neo4jOperations operations;
//	@Autowired private Neo4jTemplate template;
	
	public void saveAll()
	{
		for (Attribute attribute: this.attributeRepository.findAll())
		{
			this.attributeRepository.save(attribute);
		}
		
		for (Group group: this.groupRepository.findAll())
		{
			this.groupRepository.save(group);
		}
		
		for (Offer offer: this.offerRepository.findAll())
		{
			this.offerRepository.save(offer);
		}
		
		for (Product product: this.productRepository.findAll())
		{
			this.productRepository.save(product);
		}
	}
	
	public Attribute createAttribute(String name, Attribute.Type type, String pattern, String[] lov) throws ApplicationException
	{
		try
		{
			Attribute _this = new Attribute();
			_this.setName(name);
			_this.setType(type);
			_this.setPattern(pattern);
			_this.setLov(lov);
			
			return this.attributeRepository.save(_this);
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
			throw new ApplicationException(exception.getMessage(), exception);
		}
	}
	
	public Group createGroup(String name, final Product.Type type, Long cardinality, final Product[] content) throws ApplicationException, IncompatibleTypeException
	{
		return createGroup(name, type, cardinality, (content == null || content.length < 1) ? null : new HashSet<Product>()
		{
			private static final long serialVersionUID = -5531093392376916453L;
			{
				for (Product product: content)
				{
					if (product.getType() != type)
					{
						throw new IncompatibleTypeException("unable to save " + product.getType().getName() + " into a group of " + type.getName());
					}
					add(product);
				}
			}
		});
	}
	
	public Group createGroup(String name, Product.Type type, Long cardinality, Set<Product> content) throws ApplicationException
	{
		try
		{
			Group _this = new Group();
			_this.setName(name);
			_this.setType(type);
			_this.setCardinality(cardinality);
			_this.setContent(content);
			
			return this.groupRepository.save(_this);
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
			throw new ApplicationException(exception.getMessage(), exception);
		}
	}
	
	public Offer createOffer(Product plan, Product device, Product commitment, Long price) throws ApplicationException
	{
		try
		{
			Offer _this = new Offer();
			_this.setPlan(plan);
			_this.setDevice(device);
			_this.setCommitment(commitment);
			_this.setPrice(price);
			
			return this.offerRepository.save(_this);
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
			throw new ApplicationException(exception.getMessage(), exception);
		}
	}
	
	public Product createProduct(String code, String name, Product.Type type) throws ApplicationException
	{
		return createProduct(code, name, type, (HashSet<Attribute>) null);
	}
	
	public Product createProduct(String code, String name, Product.Type type, final Attribute[] attributes) throws ApplicationException
	{
		return createProduct(code, name, type, (attributes == null || attributes.length < 1) ? null : new HashSet<Attribute>()
		{
			private static final long serialVersionUID = -5531093392376916453L;
			{
				for (Attribute attribute: attributes)
				{
					add(attribute);
				}
			}
		});
	}

	public Product createProduct(String code, String name, Product.Type type, Set<Attribute> attributes) throws ApplicationException
	{
		try
		{
			Product _this = new Product();
			_this.setCode(code);
			_this.setName(name);
			_this.setType(type);
			_this.setAttributes(attributes);
			
			return this.productRepository.save(_this);
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
			throw new ApplicationException(exception.getMessage(), exception);
		}
	}
	
	public Group canHave(Product from, Product.Type type) throws ApplicationException
	{
		try
		{
			if (type != null)
			{
				for (Group group: from.getCanHaves())
				{
					if (type.equals(group.getType()))
					{
						return group;
					}
				}
			}
			return null;
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
			throw new ApplicationException(exception.getMessage(), exception);
		}
	}
	
	public Group mustHave(Product from, Product.Type type) throws ApplicationException
	{
		try
		{
			if (type != null)
			{
				for (Group group: from.getMustHaves())
				{
					if (type.equals(group.getType()))
					{
						return group;
					}
				}
			}
			return null;
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
			throw new ApplicationException(exception.getMessage(), exception);
		}
	}
	
	public Product findProductByCode(String code)
	{
		return this.productRepository.findByPropertyValue("code", code);
	}
}
