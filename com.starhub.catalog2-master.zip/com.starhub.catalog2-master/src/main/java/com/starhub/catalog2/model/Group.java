package com.starhub.catalog2.model;

import java.util.HashSet;
import java.util.Set;

import org.neo4j.graphdb.Direction;
import org.springframework.data.neo4j.annotation.GraphId;
import org.springframework.data.neo4j.annotation.Indexed;
import org.springframework.data.neo4j.annotation.NodeEntity;
import org.springframework.data.neo4j.annotation.RelatedTo;

@NodeEntity
public class Group
{
	@GraphId
	protected Long id;
	
	@Indexed(indexName = "group-name-index")
	protected String name;
	
	@Indexed(indexName = "group-type-index")
	protected Product.Type type;
	
	@RelatedTo(type = Relationship.CONTAINS, direction = Direction.OUTGOING)
	private Set<Product> content = new HashSet<Product>();
	
	private Long cardinality = 0L;

	public Long getId()
	{
		return id;
	}

	public void setId(Long id)
	{
		this.id = id;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public Product.Type getType()
	{
		return type;
	}

	public void setType(Product.Type type)
	{
		this.type = type;
	}

	public Set<Product> getContent()
	{
		return content;
	}

	public void setContent(Set<Product> content)
	{
		this.content = content;
	}

	public Long getCardinality()
	{
		return cardinality;
	}

	public void setCardinality(Long cardinality)
	{
		this.cardinality = cardinality;
	}
	
	@Override
	public int hashCode()
	{
		return (id == null) ? 0 : id.hashCode();
	}
	
	@Override
	public boolean equals(Object obj)
	{
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		
		Group other = (Group) obj;
		if (id == null) return other.id == null;
		return id.equals(other.id);
	}
	
	@Override
	public String toString()
	{
		return String.format("Group{id=%03d, type=%s, name=%s}", id, type, name);
	}
}
