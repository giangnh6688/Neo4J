package com.starhub.catalog2.exception;

public class ApplicationException extends Exception
{
	private static final long serialVersionUID = -4486151107210115052L;
	
	public ApplicationException()
	{
	}
	
	public ApplicationException(String message)
	{
		super(message);
	}
	
	public ApplicationException(String message, Throwable throwable)
	{
		super(message, throwable);
	}
}
