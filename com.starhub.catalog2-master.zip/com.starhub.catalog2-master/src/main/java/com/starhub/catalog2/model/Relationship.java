package com.starhub.catalog2.model;

public interface Relationship
{
	public static final String CAN_HAVE = "CAN_HAVE";
	public static final String CANNOT_HAVE = "CANNOT_HAVE";
	public static final String CONTAINS = "CONTAINS";
	public static final String HAS = "HAS";
	public static final String MUST_HAVE = "MUST_HAVE";
	public static final String OFFERS = "OFFERS";
}